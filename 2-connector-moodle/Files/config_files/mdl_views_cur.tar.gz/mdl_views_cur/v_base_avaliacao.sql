
    SELECT *, 2021 ano_base
  FROM `[prj_id_lnd].[dts_nm_lnd].base_avaliacao_f_2021`

  UNION ALL

    SELECT *, 2022 ano_base
  FROM `[prj_id_lnd].[dts_nm_lnd].base_avaliacao_f_2022`

  UNION ALL

  SELECT *, 2023 ano_base
  FROM `[prj_id_lnd].[dts_nm_lnd].base_avaliacao_f_2023`